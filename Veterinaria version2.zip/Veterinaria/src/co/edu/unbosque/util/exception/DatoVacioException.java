package co.edu.unbosque.util.exception;

public class DatoVacioException extends Exception{

	public DatoVacioException() {
		super("Debe completar el parametro");
	}
}
