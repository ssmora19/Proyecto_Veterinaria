package co.edu.unbosque.util.exception;

public class InvalidStringException extends Exception{
	
	public InvalidStringException() {
		super("En este campo no esta permitido digitar numeros");
	}

}
