package co.edu.unbosque.util.exception;

public class QuantityNumbers extends Exception{
	
	public QuantityNumbers() {
		super("Solo se permite una cantidad de 10 numeros");
	}

}
